sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function(Controller) {
    "use strict";

    return Controller.extend("sap.ui.table.sample.TreeTable.BasicODataTreeBinding.Controller", {

        onInit : function () {
            //nothing to do for us
        }

    });

});
